import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { UtilsModule } from "../utils/utils.module";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from './app.component';
import { BugTrackerComponent } from "./bugTracker/bugTracker.component";
import { BugStatsComponent } from "./bugTracker/views/bugStats.component";
import { BugEditComponent } from "./bugTracker/views/bugEdit.component";
import { ProjectEditComponent } from "./bugTracker/views/projectEdit.component";
import { ClosedCountPipe } from "./bugTracker/pipes/closedCount.pipe";
import { BugOperationsService } from './bugTracker/services/bugOperation.service';
import { ProjectOperationsService } from './bugTracker/services/projectOperation.service';
import { BugStorageService } from "./bugTracker/services/bugStorage.service";
import { BugApiService } from "./bugTracker/services/bugApi.service";
import { ProjectApiService } from './bugTracker/services/projectApi.service';
import { ProjectTrackerComponent } from './bugTracker/projectTracker.component';


@NgModule({
  declarations: [ 
    AppComponent
    , BugTrackerComponent
    , BugStatsComponent
    , BugEditComponent
    , ClosedCountPipe
    , ProjectTrackerComponent
    , ProjectEditComponent
  ],
  imports: [
    BrowserModule
    , UtilsModule
    , HttpClientModule
  ],
  providers: [
    BugOperationsService
    , BugStorageService
    , BugApiService
    , ProjectApiService
    , ProjectOperationsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
